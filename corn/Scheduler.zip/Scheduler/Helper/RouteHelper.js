const express = require("express");// || import core framework

const router = express.Router(); // || call core router function

module.exports = router;